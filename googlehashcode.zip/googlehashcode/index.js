const { readLines, write } = require('../utils/readandwrite');
const fs = require('fs');

const file = 'a_example';

const lines = readLines(`input/googlehashcode/${file}`);

write(lines, `./output/googlehashcode/${file}_out`);
